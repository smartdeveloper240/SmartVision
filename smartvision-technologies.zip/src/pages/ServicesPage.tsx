/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SERVICES_DATA } from '../data';
import { DynamicIcon } from '../components/Icons';
import { motion, AnimatePresence } from 'motion/react';

interface ServicesPageProps {
  onOpenSurvey: () => void;
}

export default function ServicesPage({ onOpenSurvey }: ServicesPageProps) {
  const [activeTab, setActiveTab] = useState<'cctv' | 'networking' | 'access-control'>('cctv');

  const tabOptions = [
    { id: 'cctv', label: 'Surveillance Systems', icon: 'Camera' },
    { id: 'networking', label: 'Networking & Fiber', icon: 'Network' },
    { id: 'access-control', label: 'Access Control & intercoms', icon: 'Lock' }
  ] as const;

  const getDetailedSpecs = (tabId: string) => {
    switch (tabId) {
      case 'cctv':
        return {
          header: "Enterprise CCTV & Surveillance Architecture",
          intro: "We deploy state-of-the-art optical hardware connected to high-end network recording modules, designed to ensure comprehensive continuous sightlines over valuable property assets.",
          details: [
            {
              title: "Certified Professional Installation",
              desc: "Every dome, bullet, or PTZ camera is mounted using commercial hardware anchors. Cables are fully structured in protective conduits with perfect vertical drops.",
              bullets: ["Sighted camera placement matching laser parameters", "Weatherproof IP67 aluminum vaults", "Protected heavy-duty terminal boxes"]
            },
            {
              title: "Encrypted Mobile Remote Monitoring",
              desc: "Get remote access to live video feeds from your personal device. Keep track of employees, client flow, and parking lots with zero monthly licensing cloud feeds.",
              bullets: ["Secure sub-stream compression for mobile bandwidths", "Push-alerts on custom coordinate motion triggers", "Multi-tenancy segmentation for sub-administrative access"]
            },
            {
              title: "Comprehensive AMC Protection",
              desc: "Our Annual Maintenance Contracts are engineered to guarantee maximum operating lifespans. We clean lenses, swap broken power supplies, and patch system vulnerabilities proactively.",
              bullets: ["Quarterly proactive technician on-site checkups", "Firmware security updates with on-site logging", "Zero-cost replacement of worn power adapters / terminals"]
            }
          ]
        };
      case 'networking':
        return {
          header: "Structured Cabling & Fiber Optic Backbones",
          intro: "Secure communication pipeline planning. We architect low-loss corporate internal LAN networks, robust wireless grids, and high-bandwidth fiber optic links.",
          details: [
            {
              title: "Structured Office LAN setups",
              desc: "Pragmatic server-rack terminations, patch-panels mapping, organized zip-tie configurations, and complete laser cable diagnosis before final sign-off.",
              bullets: ["Ultra-fast copper Cat6a & Cat7 certified cabling", "Meticulously organized wall ports and key plates", "Industrial rack containment & ventilation management"]
            },
            {
              title: "Wi-Fi Coverage Channel Optimization",
              desc: "Perform extensive radio-frequency mapping across multi-level real estate, allocating optimized AP overlap zones for seamless client handshakes.",
              bullets: ["State-of-the-art Wi-Fi 6 & 6E enterprise Access Points", "VLAN isolation for internal staff vs. visiting guests", "RF spectrum analysis to suppress channel interferences"]
            },
            {
              title: "Routing, Managed Switching & Fiber",
              desc: "We lay down long-range single/multimode fiber optic pipelines, configuring localized routing and firewall parameters for maximum threat resistance.",
              bullets: ["Fiber termination using high-precision core splicers", "Active layer-2 / layer-3 switches with high VLAN configs", "Hardware firewall filters preventing network intrusion"]
            }
          ]
        };
      case 'access-control':
        return {
          header: "Integrated Biometrics & Custom Access Gateways",
          intro: "Regulate physical entries. Replace easy-to-copy keys or physical tags with high-precision biometric databases and synchronized video monitors.",
          details: [
            {
              title: "Advanced Biometrics & Face Scanners",
              desc: "Highly robust scanning panels displaying zero lag. Deploy facial scanning stations or secure fingerprint pads across internal boundaries.",
              bullets: ["Dual-scanning credentials (RFID cards + fingerprint keys)", "Under 0.2-second facial verification accuracy", "Unified management database of current internal staff"]
            },
            {
              title: "Video Intercoms & Gate Door Phones",
              desc: "Evaluate outdoor visitors with crystal clear premium indoor screens, maintaining communication control from anywhere inside the office or residence.",
              bullets: ["Interactive HD outdoor intercom terminals with night-sight", "Two-way sound suppression prevents background noise", "Instant magnetic lock release trigger from desktop or monitor"]
            },
            {
              title: "Central Central Monitoring integrations",
              desc: "Connect your card terminals and lock controllers with centralized computer dashboards to receive immediate logging updates during unauthorized sweeps.",
              bullets: ["Instant log audit trails of employee checkout events", "Integrated magnetic lock fire-alarm emergency override", "Seamless integration with nearby CCTV camera trigger points"]
            }
          ]
        };
      default:
        return { header: "", intro: "", details: [] };
    }
  };

  const selectedSpec = getDetailedSpecs(activeTab);

  return (
    <div id="services-page" className="space-y-16 pt-28 pb-16">
      
      {/* Informative Header Banner */}
      <section className="bg-slate-900 text-white py-14 sm:py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
          <span className="text-cyan-400 font-mono text-xs uppercase tracking-widest font-bold">
            Smart Solutions Portfolio
          </span>
          <h1 className="text-3xl sm:text-5xl font-sans font-extrabold tracking-tight">
            Advanced Technical Solutions
          </h1>
          <p className="text-slate-300 text-sm sm:text-base max-w-2xl mx-auto">
            Explore deep technical specifications, design details, structural benefits, and parameters matching our elite corporate offerings.
          </p>
        </div>
      </section>

      {/* Tabs Selector Navigation Bar (Sticky feel) */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 bg-slate-100 p-2 rounded-2xl border border-slate-200">
          {tabOptions.map((opt) => {
            const isSelected = activeTab === opt.id;
            return (
              <button
                key={opt.id}
                onClick={() => setActiveTab(opt.id)}
                className={`w-full sm:w-auto px-6 py-3 rounded-xl font-bold text-sm tracking-wide flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-slate-950 text-white shadow-md'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <DynamicIcon name={opt.icon} className={`w-4.5 h-4.5 ${isSelected ? 'text-cyan-400' : ''}`} />
                <span>{opt.label}</span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Main Spec Panels */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="space-y-12"
          >
            
            {/* Lead Narrative */}
            <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-10 space-y-4">
              <h2 className="text-slate-950 text-2xl sm:text-3xl font-sans font-extrabold tracking-tight">
                {selectedSpec.header}
              </h2>
              <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
                {selectedSpec.intro}
              </p>
            </div>

            {/* Spec Columns Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {selectedSpec.details.map((item, idx) => (
                <div
                  key={idx}
                  className="bg-white border border-slate-200 hover:border-cyan-400/40 rounded-2xl p-6 shadow-sm flex flex-col justify-between hover:shadow-lg transition-all duration-300 relative group"
                >
                  <div className="space-y-4">
                    <span className="font-mono text-slate-300 text-sm font-bold block">
                      SPEC MODULE / 0{idx + 1}
                    </span>
                    <h3 className="text-slate-950 font-bold text-lg leading-tight">
                      {item.title}
                    </h3>
                    <p className="text-slate-600 text-xs leading-relaxed">
                      {item.desc}
                    </p>
                    
                    {/* Inner bullets info */}
                    <div className="border-t border-slate-100 pt-4 space-y-2">
                      {item.bullets.map((bURL, bIdx) => (
                        <div key={bIdx} className="flex items-start gap-2 text-xs text-slate-700 leading-normal">
                          <DynamicIcon name="Check" className="w-3.5 h-3.5 text-cyan-500 shrink-0 mt-0.5" />
                          <span>{bURL}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Layout Demonstration Card with Generated Image (only for CCTV first) */}
            {activeTab === 'cctv' && (
              <div className="bg-slate-950 border border-slate-850 rounded-3xl p-6 sm:p-8 grid grid-cols-1 md:grid-cols-2 gap-8 items-center overflow-hidden">
                <div className="space-y-4">
                  <span className="text-cyan-400 font-mono text-[10px] uppercase tracking-widest font-bold">
                    PREMIUM DEPLOYMENT SPECIMEN
                  </span>
                  <h3 className="text-white text-xl sm:text-2xl font-bold tracking-tight">
                    Minimalist Dome CCTV Design
                  </h3>
                  <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                    Our high-contrast dome configurations are low-profile yet yield excellent deterrent utility. Combined with power-over-ethernet (PoE) channels and industrial casing protection, they run stably under active continuous cycles.
                  </p>
                  <ul className="text-xs text-slate-400 space-y-1.5 font-mono">
                    <li>• Model Class: UHD ST-890 enterprise Series</li>
                    <li>• Optic Sensor: Sony Starvis Ultra HD low-light</li>
                    <li>• Compression Stack: H.265 high efficiency profiles</li>
                  </ul>
                </div>
                
                {/* Visual Image container */}
                <div className="rounded-xl overflow-hidden border border-slate-800 shadow-2xl h-48 sm:h-64 relative bg-slate-900">
                  <img
                    src="/src/assets/images/smartvision_cctv_1781679350875.jpg"
                    alt="Sleek SmartVision corporate dome CCTV"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-cyan-950/80 border border-cyan-500/30 text-cyan-400 px-3 py-1 rounded text-[10px] font-mono tracking-widest uppercase">
                    HD/IP 2026 OUTLINE
                  </div>
                </div>
              </div>
            )}

            {/* Tabbing Footer Call to action */}
            <div className="bg-cyan-50/55 border border-cyan-200/50 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6">
              <div className="space-y-1.5 text-center sm:text-left">
                <h4 className="text-slate-950 font-bold text-lg">
                  Ready to deploy these specifications or layouts?
                </h4>
                <p className="text-slate-600 text-xs sm:text-sm">
                  We schedule rapid-response physical surveys to plan your cable lengths and hardware models.
                </p>
              </div>
              <button
                onClick={onOpenSurvey}
                className="bg-cyan-500 hover:bg-cyan-450 text-slate-950 px-6 py-3 rounded-xl font-bold text-sm tracking-wide whitespace-nowrap cursor-pointer transition shadow"
              >
                Book Survey Survey
              </button>
            </div>

          </motion.div>
        </AnimatePresence>
      </section>

    </div>
  );
}
