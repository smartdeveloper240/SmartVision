/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PageId } from '../types';
import { SERVICES_DATA, WHY_CHOOSE_US, INDUSTRIES_DATA, OUR_REVIEWS, FREQUENT_QUESTIONS } from '../data';
import { DynamicIcon } from '../components/Icons';
import { motion } from 'motion/react';

interface HomeProps {
  onNavigate: (page: PageId) => void;
  onOpenSurvey: () => void;
}

export default function Home({ onNavigate, onOpenSurvey }: HomeProps) {
  const [activeIndustryId, setActiveIndustryId] = useState<string>('residential');
  const [expandedFAQIndex, setExpandedFAQIndex] = useState<number | null>(null);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { y: 25, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { type: 'spring', stiffness: 100 }
    }
  };

  return (
    <div id="home-page" className="space-y-20 pb-16">
      
      {/* HERO SECTION */}
      <section id="hero-banner" className="relative min-h-[90vh] bg-slate-950 flex items-center pt-24 overflow-hidden">
        {/* Background Image with cybernetic dimming overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/smartvision_hero_1781679332176.jpg"
            alt="SmartVision corporate server backbone room"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-35 filter brightness-75 bg-slate-950"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/60 to-transparent"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full py-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Hero Left Content */}
            <div className="lg:col-span-7 space-y-6 sm:space-y-8">
              <span className="inline-flex items-center gap-2 px-3 py-1 bg-cyan-950/60 border border-cyan-850/60 text-cyan-400 rounded-full text-xs font-mono tracking-widest font-bold uppercase animate-pulse">
                <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                ENTERPRISE CERTIFIED SERVICES
              </span>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-sans font-extrabold text-white tracking-tight leading-tight">
                Smart Security.<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-cyan-300 to-teal-400">
                  Smart Connectivity.
                </span>
              </h1>
              
              <p className="text-slate-300 text-lg leading-relaxed max-w-xl">
                Professional CCTV surveillance, high-speed networking, and smart security infrastructure solutions for homes, offices, and industries. We keep you connected, protected, and secure.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={onOpenSurvey}
                  className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 px-8 py-4 rounded-xl text-base font-bold tracking-wide transition shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-3 cursor-pointer transform active:scale-95"
                >
                  Request a Free Site Survey
                  <DynamicIcon name="ArrowRight" className="w-5 h-5 text-slate-950" />
                </button>
                <button
                  onClick={() => onNavigate('services')}
                  className="bg-slate-900 hover:bg-slate-800 text-white border border-slate-700 hover:border-slate-500 px-8 py-4 rounded-xl text-base font-bold tracking-wide transition flex items-center justify-center gap-2 cursor-pointer transform active:scale-95"
                >
                  Explore Services
                </button>
              </div>

              {/* Minimalist Tech Metrics */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-800/80 max-w-lg">
                <div>
                  <h4 className="text-white text-2xl font-bold font-mono">1500+</h4>
                  <p className="text-slate-400 text-xs">Deployments Completed</p>
                </div>
                <div>
                  <h4 className="text-white text-2xl font-bold font-mono">24/7</h4>
                  <p className="text-slate-400 text-xs">AMC Remote Controls</p>
                </div>
                <div>
                  <h4 className="text-white text-2xl font-bold font-mono">99.9%</h4>
                  <p className="text-slate-400 text-xs">Network Node Uptime</p>
                </div>
              </div>
            </div>

            {/* Hero Right Interactive Dashboard Widget */}
            <div className="lg:col-span-5 hidden lg:block">
              <div className="bg-slate-900/90 border border-slate-850 p-6 rounded-2xl shadow-2xl relative overflow-hidden backdrop-blur-md">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 to-teal-400"></div>
                
                {/* Simulated control console */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 bg-cyan-500 rounded-full animate-ping"></span>
                    <span className="text-xs font-mono tracking-widest text-slate-400 font-extrabold uppercase">
                      SYSTEM INTEGRATION: ONLINE
                    </span>
                  </div>
                  <DynamicIcon name="Shield" className="w-5 h-5 text-cyan-400" />
                </div>

                <div className="space-y-4">
                  <div className="bg-slate-950 p-3 rounded border border-slate-800/60 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-1.5 bg-cyan-950/60 rounded text-cyan-400">
                        <DynamicIcon name="Camera" size={16} />
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-slate-200 block">Surveillance Logs</span>
                        <span className="text-[10px] text-slate-500 font-mono">32 Cameras Configured</span>
                      </div>
                    </div>
                    <span className="text-emerald-400 text-xs font-semibold font-mono">Active Monitoring</span>
                  </div>

                  <div className="bg-slate-950 p-3 rounded border border-slate-800/60 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-1.5 bg-teal-950 rounded text-teal-400">
                        <DynamicIcon name="Network" size={16} />
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-slate-200 block">High-Speed Office LAN</span>
                        <span className="text-[10px] text-slate-500 font-mono">Mesh Opt / Fiber Up</span>
                      </div>
                    </div>
                    <span className="text-teal-400 text-xs font-semibold font-mono">1.2 Gbps Stabilized</span>
                  </div>

                  <div className="bg-slate-950 p-3 rounded border border-slate-800/60 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-1.5 bg-purple-950 rounded text-purple-400">
                        <DynamicIcon name="Lock" size={16} />
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-slate-200 block">Access Gates</span>
                        <span className="text-[10px] text-slate-500 font-mono">Biometrics Encrypted</span>
                      </div>
                    </div>
                    <span className="text-purple-400 text-xs font-semibold font-mono">Locks Secured</span>
                  </div>
                </div>

                {/* Instant Action Prompt */}
                <div className="mt-6 bg-cyan-950/45 border border-cyan-850/30 p-4 rounded-xl flex items-center justify-between gap-3">
                  <p className="text-slate-300 text-xs leading-relaxed">
                    Review physical floorplans and request custom camera layouts.
                  </p>
                  <button
                    onClick={onOpenSurvey}
                    className="bg-cyan-500 text-slate-950 p-2 rounded-lg hover:bg-cyan-400 transition shrink-0 cursor-pointer"
                  >
                    <DynamicIcon name="ArrowRight" className="w-4 h-4 text-slate-950" />
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>


      {/* SERVICES OVERVIEW SECTION */}
      <section id="services-overview" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-cyan-500 font-mono text-xs uppercase tracking-widest font-bold">
            Comprehensive Capabilities
          </span>
          <h2 className="text-3xl sm:text-4xl font-sans font-extrabold text-slate-950 tracking-tight">
            Our Premium Services
          </h2>
          <p className="text-slate-600 text-sm">
            Pragmatic design, installation, and Annual Maintenance support of mission-critical corporate security systems.
          </p>
        </div>

        {/* 3-Column Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          {SERVICES_DATA.map((service, idx) => (
            <div
              key={service.id}
              className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-sm hover:shadow-xl hover:border-cyan-400/50 transition-all duration-300 group"
            >
              <div className="space-y-6">
                
                {/* Header Icon Block */}
                <div className="flex items-center justify-between">
                  <div className="bg-slate-950 text-white p-3.5 rounded-xl group-hover:bg-cyan-500 group-hover:text-slate-950 transition-colors duration-300">
                    <DynamicIcon name={service.iconName} className="w-6 h-6" />
                  </div>
                  <span className="text-slate-300 font-mono text-lg font-bold">0{idx + 1}</span>
                </div>

                {/* Text Details */}
                <div className="space-y-3">
                  <h3 className="font-sans font-extrabold text-slate-950 text-xl tracking-tight">
                    {service.title}
                  </h3>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    {service.shortDesc}
                  </p>
                </div>

                {/* Mini Checklist */}
                <ul className="space-y-2 border-t border-slate-100 pt-4">
                  {service.features.map((feat, f_idx) => (
                    <li key={f_idx} className="flex items-start gap-2.5 text-xs text-slate-700 leading-normal">
                      <DynamicIcon name="Check" className="w-4 h-4 text-cyan-500 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action link */}
              <div className="pt-6 mt-6 border-t border-slate-100">
                <button
                  onClick={() => {
                    // Navigate to services page and select appropriate anchor/tab
                    onNavigate('services');
                    window.scrollTo(0,0);
                  }}
                  className="text-cyan-500 hover:text-cyan-600 text-sm font-bold flex items-center gap-1.5 cursor-pointer group-hover:underline"
                >
                  <span>Learn more parameters</span>
                  <DynamicIcon name="ArrowRight" className="w-4.5 h-4.5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>


      {/* WHY CHOOSE US SECTION */}
      <section id="why-choose-us" className="bg-slate-50 border-y border-slate-200/80 py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Narrative Block */}
            <div className="lg:col-span-5 space-y-6">
              <span className="text-cyan-500 font-mono text-xs uppercase tracking-widest font-bold">
                Why SmartVision Technologies
              </span>
              <h2 className="text-3xl sm:text-4xl font-sans font-extrabold text-slate-950 tracking-tight leading-tight">
                Designed for Safety.<br />
                Engineered for Speed.
              </h2>
              <p className="text-slate-600 text-sm leading-relaxed">
                As physical threats and software requirements become increasingly complex, you need an integrated technical partner that provides professional layout planning and transparent pricing. 
              </p>
              
              <div className="bg-white border border-slate-200 p-4 rounded-xl space-y-2">
                <p className="text-slate-500 italic text-xs leading-relaxed">
                  "SmartVision converted our chaotic unstructured cabling setup into an impeccably organized rack system. Our Wi-Fi dropped connection issues fell to zero instantly."
                </p>
                <p className="text-xs font-bold text-slate-950">
                  — Lead IT Planner, Innovation Tech Hub
                </p>
              </div>

              <div className="pt-2">
                <button
                  onClick={onOpenSurvey}
                  className="bg-slate-950 hover:bg-slate-850 text-white px-6 py-3 rounded-xl text-sm font-bold transition shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Claim Your Free Survey</span>
                  <DynamicIcon name="ArrowRight" className="w-4 h-4 text-white" />
                </button>
              </div>
            </div>

            {/* Right Value Grid */}
            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-5">
              {WHY_CHOOSE_US.map((value, idx) => (
                <div
                  key={idx}
                  className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3 hover:border-cyan-400/40 hover:shadow-md transition-all duration-300"
                >
                  <div className="p-2.5 bg-slate-950 text-white w-fit rounded-lg">
                    <DynamicIcon name={value.iconName} className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-slate-950 text-base leading-tight">
                    {value.title}
                  </h3>
                  <p className="text-slate-600 text-xs leading-relaxed">
                    {value.description}
                  </p>
                </div>
              ))}
            </div>

          </div>
        </div>
      </section>


      {/* INDUSTRIES WE SERVE GRID (Interactive Bento Layout) */}
      <section id="industries-serve" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end pb-8 border-b border-slate-200">
          <div className="lg:col-span-7 space-y-3 text-left">
            <span className="text-cyan-500 font-mono text-xs uppercase tracking-widest font-bold">
              Versatile Deployments
            </span>
            <h2 className="text-3xl sm:text-4xl font-sans font-extrabold text-slate-950 tracking-tight">
              Industries We Secure & Connect
            </h2>
          </div>
          <p className="lg:col-span-5 text-slate-600 text-sm leading-relaxed">
            Every sector poses distinct architectural hurdles. We assemble tailored camera heights, specific network encryptions, and durable hardware.
          </p>
        </div>

        {/* Bento Selector */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-12 items-start">
          
          {/* Left: Quick Selector list */}
          <div className="lg:col-span-4 space-y-2">
            {INDUSTRIES_DATA.map((ind) => (
              <button
                key={ind.id}
                onClick={() => setActiveIndustryId(ind.id)}
                className={`w-full text-left p-4 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                  activeIndustryId === ind.id
                    ? 'bg-slate-950 text-white border-slate-950 shadow-md transform translate-x-1'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${activeIndustryId === ind.id ? 'bg-cyan-500 text-slate-950' : 'bg-slate-100 text-slate-700'}`}>
                    <DynamicIcon name={ind.iconName} className="w-5 h-5 animate-none" />
                  </div>
                  <span className="font-bold text-sm tracking-wide">{ind.title}</span>
                </div>
                <DynamicIcon
                  name="ChevronRight"
                  className={`w-4 h-4 transition-transform ${activeIndustryId === ind.id ? 'translate-x-1' : ''}`}
                />
              </button>
            ))}
          </div>

          {/* Right: Detailed parameters with anims */}
          <div className="lg:col-span-8">
            {INDUSTRIES_DATA.map((ind) => {
              if (ind.id !== activeIndustryId) return null;
              return (
                <motion.div
                  key={ind.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                  className="bg-slate-900 border border-slate-850 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl relative"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-3xl"></div>
                  
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <span className="bg-cyan-950/60 text-cyan-400 border border-cyan-800/40 text-[10px] font-mono tracking-widest uppercase px-2 py-0.5 rounded-full">
                        {ind.tag}
                      </span>
                      <h3 className="text-white text-2xl font-extrabold tracking-tight pt-1.5">
                        {ind.title}
                      </h3>
                    </div>
                    <div className="p-3 bg-cyan-500 text-slate-950 rounded-xl w-fit">
                      <DynamicIcon name={ind.iconName} className="w-6 h-6 text-slate-950" />
                    </div>
                  </div>

                  <p className="text-slate-300 text-sm leading-relaxed border-t border-slate-800/80 pt-4">
                    {ind.description}
                  </p>

                  <div className="space-y-3 pt-2">
                    <h4 className="text-slate-400 font-semibold text-xs tracking-wider uppercase font-mono">
                      Specialized Solutions Deployed:
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {ind.details.map((det, idx) => (
                        <div
                          key={idx}
                          className="bg-slate-950 border border-slate-800/60 p-3 rounded-lg flex items-center gap-3"
                        >
                          <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full shrink-0"></div>
                          <span className="text-xs text-white tracking-wide">{det}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Active Prompt info */}
                  <div className="bg-cyan-950/20 border border-cyan-800/20 p-4 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
                    <span className="text-xs text-slate-300">
                      Need industry-standard configurations? Let our field team audit your layout dimensions.
                    </span>
                    <button
                      onClick={onOpenSurvey}
                      className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs cursor-pointer tracking-wider shrink-0"
                    >
                      Audit My Site Now
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>

        </div>
      </section>

      {/* CLIENT REVIEWS */}
      <section id="reviews-carousel" className="bg-slate-900 border-y border-slate-800 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto space-y-2 mb-12">
            <span className="text-cyan-400 font-mono text-xs uppercase tracking-widest font-bold">
              Trusted by Professionals
            </span>
            <h2 className="text-3xl text-white font-sans font-extrabold tracking-tight">
              Customer Feedback
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {OUR_REVIEWS.map((rev, idx) => (
              <div key={idx} className="bg-slate-950 border border-slate-850 p-6 rounded-2xl flex flex-col justify-between shadow-lg">
                <div className="space-y-4">
                  <div className="flex gap-1">
                    {[...Array(rev.rating)].map((_, i) => (
                      <DynamicIcon key={i} name="Star" className="w-4 h-4 text-amber-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-slate-300 text-xs sm:text-sm leading-relaxed italic">
                    "{rev.quote}"
                  </p>
                </div>
                <div className="pt-4 border-t border-slate-900 mt-6">
                  <p className="text-white font-bold text-xs sm:text-sm">{rev.author}</p>
                  <p className="text-slate-500 text-[11px] font-mono mt-0.5">{rev.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FREQUENT INTERACTIVE ACCORDIONS */}
      <section id="faq-accordions" className="max-w-3xl mx-auto px-4 sm:px-6">
        <div className="text-center space-y-3 mb-10">
          <span className="text-cyan-500 font-mono text-xs uppercase tracking-widest font-bold">
            Got Questions?
          </span>
          <h2 className="text-2xl sm:text-3xl font-sans font-extrabold text-slate-950 tracking-tight">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="space-y-4">
          {FREQUENT_QUESTIONS.map((faq, idx) => {
            const isExpanded = expandedFAQIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm"
              >
                <button
                  onClick={() => setExpandedFAQIndex(isExpanded ? null : idx)}
                  className="w-full text-left px-5 py-4 flex items-center justify-between gap-4 font-bold text-sm tracking-wide text-slate-950 bg-white hover:bg-slate-50 transition cursor-pointer"
                >
                  <span>{faq.question}</span>
                  <DynamicIcon
                    name="ChevronDown"
                    className={`w-4 h-4 text-slate-500 transition-transform duration-300 ${isExpanded ? 'rotate-185' : ''}`}
                  />
                </button>
                {isExpanded && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

    </div>
  );
}
