/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { DynamicIcon } from '../components/Icons';
import { motion } from 'motion/react';

export default function About() {
  const brandValues = [
    {
      title: 'Unyielding Integrity',
      description: 'We adhere to absolute transparency in parts specifications, diagnostic checklists, security protocols, and competitive pricing parameters.',
      iconName: 'Shield'
    },
    {
      title: 'Technological Excellence',
      description: 'Our certified engineers undergo rigorous continuing technical training to master next-gen IP analytics, Wi-Fi 6 channels, and optical mechanics.',
      iconName: 'Award'
    },
    {
      title: 'Unfailing Safety First',
      description: 'Physical security layouts require electrical safety, proper grounding, code-compliant cabling supports, and failsafe fire-alarm releases.',
      iconName: 'ShieldAlert'
    },
    {
      title: 'Customer-Centric Operations',
      description: 'Our Annual Maintenance Contracts are backed by real responsive professionals, available same-day and on call for emergency dispatch.',
      iconName: 'Users'
    }
  ];

  const milestones = [
    { year: '2016', title: 'Company Launch', desc: 'SmartVision Technologies established with a team of 3 certified CCTV technicians.' },
    { year: '2019', title: 'Networking Division', desc: 'Introduced high-speed structured IT cabling and switching/routing optimization services.' },
    { year: '2022', title: 'Smart Access Expansion', desc: 'Launched integrated biometrics, facial-geometry readers, and central command surveillance setups.' },
    { year: '2025', title: 'Next-Gen AMC Protocol', desc: 'Deployed continuous remote monitoring capabilities and automated dispatch modules.' }
  ];

  return (
    <div id="about-page" className="space-y-20 pt-28 pb-16">
      
      {/* Intro Hero Header */}
      <section className="bg-slate-900 text-white py-16 sm:py-24 relative overflow-hidden">
        {/* Abstract background lights */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl space-y-4">
            <span className="text-cyan-400 font-mono text-xs uppercase tracking-widest font-bold">
              Engineering Trust Since 2016
            </span>
            <h1 className="text-4xl sm:text-5xl font-sans font-extrabold tracking-tight">
              About SmartVision Technologies
            </h1>
            <p className="text-slate-300 text-base sm:text-lg leading-relaxed pt-2">
              We guide and protect modern businesses, educational complexes, industrial hubs, and elegant homes with robust security hardware and seamless high-speed connectivity solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 sm:gap-12">
          
          {/* Mission Card */}
          <div className="bg-white border-l-4 border-cyan-500 rounded-r-2xl border-y border-r border-slate-200 p-8 sm:p-10 shadow-sm space-y-6 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="bg-cyan-50 text-cyan-600 p-3 rounded-xl w-fit">
                <DynamicIcon name="Sliders" className="w-6 h-6 text-cyan-600" />
              </div>
              <h2 className="text-slate-950 font-sans font-extrabold text-2xl tracking-tight">
                Our Corporate Mission
              </h2>
              <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
                To provide reliable, innovative, and cost-effective security and networking solutions that protect assets, improve connectivity, and inspire confidence.
              </p>
            </div>
            
            <div className="text-xs text-cyan-600 font-mono bg-cyan-50/50 p-3 rounded-lg border border-cyan-100 mt-4">
              🎯 Standard: 100% Client Satisfaction & Zero Blindspots
            </div>
          </div>

          {/* Vision Card */}
          <div className="bg-white border-l-4 border-teal-500 rounded-r-2xl border-y border-r border-slate-200 p-8 sm:p-10 shadow-sm space-y-6 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="bg-teal-50 text-teal-600 p-3 rounded-xl w-fit">
                <DynamicIcon name="Award" className="w-6 h-6 text-teal-600" />
              </div>
              <h2 className="text-slate-950 font-sans font-extrabold text-2xl tracking-tight">
                Our Future Vision
              </h2>
              <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
                To become a trusted technology partner and highly respected provider by delivering excellence, innovation, and exceptional customer service.
              </p>
            </div>

            <div className="text-xs text-teal-600 font-mono bg-teal-50/50 p-3 rounded-lg border border-teal-100 mt-4">
              💡 Target: High-Grade IT Integration across North America
            </div>
          </div>

        </div>
      </section>

      {/* Core Values Section */}
      <section className="bg-slate-50 border-y border-slate-200 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto space-y-3 mb-12">
            <span className="text-cyan-500 font-mono text-xs uppercase tracking-widest font-bold">
              Our Foundations
            </span>
            <h2 className="text-3xl font-sans font-extrabold text-slate-950 tracking-tight">
              Values We Live By
            </h2>
            <p className="text-slate-600 text-sm">
              We hold our products, support staff, and field engineering execution to elite enterprise benchmarks.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {brandValues.map((val, idx) => (
              <div
                key={idx}
                className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4 hover:shadow-md transition-shadow"
              >
                <div className="p-2.5 bg-slate-950 text-white rounded-lg w-fit">
                  <DynamicIcon name={val.iconName} className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-950 text-base leading-snug">
                  {val.title}
                </h3>
                <p className="text-slate-600 text-xs leading-relaxed">
                  {val.description}
                </p>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Timeline Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-16">
          <span className="text-cyan-500 font-mono text-xs uppercase tracking-widest font-bold">
            History of Innovation
          </span>
          <h2 className="text-3xl font-sans font-extrabold text-slate-950 tracking-tight">
            Our Journey Milestones
          </h2>
        </div>

        {/* Timeline Layout */}
        <div className="relative border-l-2 border-slate-200 max-w-3xl mx-auto pl-6 sm:pl-10 space-y-12">
          {milestones.map((mil, idx) => (
            <div key={idx} className="relative">
              {/* Orb */}
              <div className="absolute -left-[31px] sm:-left-[47px] top-1.5 w-4 h-4 rounded-full bg-cyan-500 border-4 border-white shadow-md"></div>
              
              <div className="space-y-2">
                <span className="text-cyan-600 font-mono font-bold text-base bg-cyan-5/50 border border-cyan-200/50 px-2.5 py-0.5 rounded-full inline-block">
                  {mil.year}
                </span>
                <h3 className="text-slate-950 font-bold text-lg">
                  {mil.title}
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed max-w-2xl">
                  {mil.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
