/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CONTACT_METADATA } from '../data';
import { DynamicIcon } from '../components/Icons';
import { motion } from 'motion/react';

export default function Contact() {
  const [activeCoverageZone, setActiveCoverageZone] = useState<string>('hq');

  const coverageZones = [
    { id: 'hq', name: 'Metro HQ & Tech District', range: '20 mile radius', activeSurveys: 'Immediate / Next-day' },
    { id: 'suburbs', name: 'Suburban Complexes', range: '45 mile radius', activeSurveys: 'Scheduled within 48h' },
    { id: 'industrial', name: 'Industrial Belt & Warehouses', range: '100 mile radius', activeSurveys: 'Specialized Team dispatch' }
  ];

  return (
    <div id="contact-page" className="space-y-16 pt-28 pb-16">
      
      {/* Intro Header */}
      <section className="bg-slate-900 text-white py-14 sm:py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-4">
          <span className="text-cyan-400 font-mono text-xs uppercase tracking-widest font-bold">
            Connect With Our Planners
          </span>
          <h1 className="text-3xl sm:text-5xl font-sans font-extrabold tracking-tight">
            Contact & Tech Support
          </h1>
          <p className="text-slate-300 text-sm sm:text-base max-w-2xl">
            Get in touch with an expert technician today. Schedule a physical layout survey, request Annual Maintenance support, or get parts configurations.
          </p>
        </div>
      </section>

      {/* Main Channels Column Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left Details block */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-2">
              <h2 className="text-slate-950 font-sans font-extrabold text-2xl tracking-tight">
                Direct Channels
              </h2>
              <p className="text-slate-600 text-sm">
                Connect with our commercial planners directly or visit our office headquarters.
              </p>
            </div>

            <div className="space-y-6">
              
              {/* Phone item */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 flex items-start gap-4">
                <div className="bg-cyan-50 text-cyan-600 p-2.5 rounded-lg shrink-0">
                  <DynamicIcon name="Phone" className="w-5 h-5 text-cyan-600" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-950 text-sm uppercase font-mono tracking-wide">
                    24/7 Support Hotline
                  </h3>
                  <a
                    href={`tel:${CONTACT_METADATA.phone}`}
                    className="text-cyan-600 hover:text-cyan-700 text-lg sm:text-xl font-bold font-mono tracking-tight block pt-0.5"
                  >
                    {CONTACT_METADATA.phone}
                  </a>
                  <p className="text-slate-500 text-xs mt-1">
                    Emergency dispatcher standby for AMC commercial SLA accounts.
                  </p>
                </div>
              </div>

              {/* Mail item */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 flex items-start gap-4">
                <div className="bg-teal-50 text-teal-600 p-2.5 rounded-lg shrink-0">
                  <DynamicIcon name="Mail" className="w-5 h-5 text-teal-600" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-950 text-sm uppercase font-mono tracking-wide">
                    Business Proposals email
                  </h3>
                  <a
                    href={`mailto:${CONTACT_METADATA.email}`}
                    className="text-cyan-600 hover:text-cyan-700 text-lg sm:text-xl font-bold tracking-tight block pt-0.5"
                  >
                    {CONTACT_METADATA.email}
                  </a>
                  <p className="text-slate-500 text-xs mt-1">
                    Send detailed system checklists, building blueprints, and bid requests.
                  </p>
                </div>
              </div>

              {/* Office Headquarters item */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 flex items-start gap-4">
                <div className="bg-slate-50 text-slate-950 p-2.5 rounded-lg shrink-0">
                  <DynamicIcon name="MapPin" className="w-5 h-5 text-slate-950" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-950 text-sm uppercase font-mono tracking-wide">
                    Office Headquarters
                  </h3>
                  <p className="text-slate-700 text-sm leading-relaxed pt-1 font-medium">
                    {CONTACT_METADATA.address}
                  </p>
                  <p className="text-slate-500 text-xs mt-1">
                    Visit our planning lab to explore high-end camera mockups and hardware racks.
                  </p>
                </div>
              </div>

            </div>

            {/* Standard hours box */}
            <div className="bg-slate-55 border border-slate-200 p-5 rounded-2xl space-y-3">
              <h4 className="text-slate-950 font-bold text-xs uppercase tracking-wider font-mono flex items-center gap-2">
                <DynamicIcon name="Clock" className="w-4.5 h-4.5 text-cyan-600" />
                Operational & Survey Hours
              </h4>
              <div className="text-xs text-slate-600 space-y-1.5 leading-normal">
                <p>Monday - Friday: <span className="font-bold text-slate-900">{CONTACT_METADATA.hours.weekdays}</span></p>
                <p>Saturdays: <span className="font-bold text-slate-900">{CONTACT_METADATA.hours.saturday}</span></p>
                <p className="text-rose-600">Sundays: <span className="font-bold text-rose-600">{CONTACT_METADATA.hours.sunday}</span></p>
              </div>
            </div>
          </div>

          {/* Right SVG coverage map placeholder layout */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-1">
              <span className="text-cyan-600 font-mono text-xs uppercase tracking-widest font-semibold block">
                Regional Service Map
              </span>
              <h2 className="text-slate-950 font-sans font-extrabold text-2xl tracking-tight">
                Our Service Coverage Area
              </h2>
              <p className="text-slate-600 text-sm">
                SmartVision engineers are actively dispatched across our metropolitan sector.
              </p>
            </div>

            {/* Simulated interactive map layout */}
            <div className="bg-slate-950 border border-slate-850 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-lg relative min-h-[400px]">
              
              {/* SVG Abstract regional map representation */}
              <div className="absolute inset-0 opacity-20 pointer-events-none p-4 flex items-center justify-center">
                <svg
                  viewBox="0 0 100 100"
                  className="w-full h-full text-cyan-500 p-8"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="0.15"
                >
                  {/* Grid lines */}
                  <line x1="0" y1="10" x2="100" y2="10" strokeDasharray="1,1" />
                  <line x1="0" y1="30" x2="100" y2="30" strokeDasharray="1,1" />
                  <line x1="0" y1="50" x2="100" y2="50" strokeDasharray="1,1" />
                  <line x1="0" y1="70" x2="100" y2="70" strokeDasharray="1,1" />
                  <line x1="0" y1="90" x2="100" y2="90" strokeDasharray="1,1" />
                  
                  <line x1="10" y1="0" x2="10" y2="100" strokeDasharray="1,1" />
                  <line x1="30" y1="0" x2="30" y2="100" strokeDasharray="1,1" />
                  <line x1="50" y1="0" x2="50" y2="100" strokeDasharray="1,1" />
                  <line x1="70" y1="0" x2="70" y2="100" strokeDasharray="1,1" />
                  <line x1="90" y1="0" x2="90" y2="100" strokeDasharray="1,1" />

                  {/* Concentric coverage arcs */}
                  <circle cx="50" cy="50" r="15" strokeDasharray="2,2" />
                  <circle cx="50" cy="50" r="30" strokeDasharray="2,2" />
                  <circle cx="50" cy="50" r="45" strokeDasharray="2,2" />

                  {/* Abstract boundaries */}
                  <path d="M 20,20 Q 30,10 50,20 T 80,40 T 90,80 T 50,90 T 10,70 Z" />
                  
                  {/* Connectors */}
                  <line x1="50" y1="50" x2="30" y2="35" strokeWidth="0.1" />
                  <line x1="50" y1="50" x2="70" y2="60" strokeWidth="0.1" strokeDasharray="1,1" />
                  <line x1="50" y1="50" x2="45" y2="75" strokeWidth="0.1" />
                </svg>
              </div>

              {/* Pulsing indicator pins mapped */}
              <div className="relative z-10 flex-1 flex flex-col justify-between">
                
                {/* Upper Status HUD */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 bg-cyan-400 rounded-full animate-ping"></span>
                    <span className="text-slate-400 font-mono text-[10px] uppercase font-bold tracking-widest">
                      ACTIVE SURVEY DISPATCH MAP
                    </span>
                  </div>
                  <span className="text-teal-400 text-xs font-mono font-bold bg-teal-950 px-2 py-0.5 rounded border border-teal-900/60">
                    SLA STANDBY
                  </span>
                </div>

                {/* Simulated Pins inside map zone */}
                <div className="relative w-full h-[220px] flex items-center justify-center">
                  
                  {/* Central HQ Pin */}
                  <div className="absolute top-[40%] left-[50%] transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
                    <div className="relative">
                      <div className="absolute -inset-1.5 bg-cyan-500 rounded-full animate-ping opacity-60"></div>
                      <div className="relative bg-cyan-500 text-slate-950 p-1.5 rounded-full flex items-center justify-center w-6 h-6 border border-white">
                        <DynamicIcon name="Shield" className="w-3.5 h-3.5 text-slate-950 font-bold" />
                      </div>
                    </div>
                    <span className="text-[10px] text-white bg-slate-950 px-2 py-0.5 rounded mt-1 font-mono uppercase tracking-wide border border-slate-800">
                      HQ LAB / ACTIVE
                    </span>
                  </div>

                  {/* Residential Pin */}
                  <div className="absolute top-[18%] left-[22%] flex flex-col items-center">
                    <div className="relative cursor-pointer" onClick={() => setActiveCoverageZone('suburbs')}>
                      <div className="absolute -inset-1.5 bg-teal-500 rounded-full animate-pulse opacity-40"></div>
                      <div className="relative bg-teal-500 text-slate-950 p-1 rounded-full flex items-center justify-center w-5 h-5 border border-white">
                        <DynamicIcon name="Home" className="w-2.5 h-2.5 text-slate-950" />
                      </div>
                    </div>
                    <span className="text-[9px] text-slate-300 bg-slate-950/80 px-1.5 py-0.5 rounded mt-0.5 font-mono">
                      Suburbs Zone
                    </span>
                  </div>

                  {/* Industrial Belt Pin */}
                  <div className="absolute bottom-[20%] right-[18%] flex flex-col items-center">
                    <div className="relative cursor-pointer" onClick={() => setActiveCoverageZone('industrial')}>
                      <div className="absolute -inset-1.5 bg-purple-500 rounded-full animate-pulse opacity-40"></div>
                      <div className="relative bg-purple-500 text-slate-950 p-1 rounded-full flex items-center justify-center w-5 h-5 border border-white">
                        <DynamicIcon name="Cpu" className="w-2.5 h-2.5 text-slate-950" />
                      </div>
                    </div>
                    <span className="text-[9px] text-slate-300 bg-slate-950/80 px-1.5 py-0.5 rounded mt-0.5 font-mono">
                      Industrial belt
                    </span>
                  </div>

                </div>

                {/* Bottom interactive cards switcher */}
                <div className="space-y-3 pt-4 border-t border-slate-800">
                  <div className="flex gap-2">
                    {coverageZones.map(zone => (
                      <button
                        key={zone.id}
                        onClick={() => setActiveCoverageZone(zone.id)}
                        className={`text-[10px] sm:text-xs px-2.5 py-1.5 rounded cursor-pointer font-bold transition ${
                          activeCoverageZone === zone.id
                            ? 'bg-cyan-500 text-slate-950'
                            : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
                        }`}
                      >
                        {zone.name.split(' & ')[0]}
                      </button>
                    ))}
                  </div>

                  {/* Details of active coverage zone */}
                  {coverageZones.map(zone => {
                    if (zone.id !== activeCoverageZone) return null;
                    return (
                      <div key={zone.id} className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg grid grid-cols-2 gap-4 text-xs">
                        <div>
                          <span className="text-slate-500 block uppercase text-[9px] font-mono">Coverage range:</span>
                          <span className="text-white font-bold">{zone.range}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block uppercase text-[9px] font-mono">Survey availability:</span>
                          <span className="text-cyan-400 font-bold">{zone.activeSurveys}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>

              </div>

            </div>
          </div>

        </div>
      </section>

    </div>
  );
}
