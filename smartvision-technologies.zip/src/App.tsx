/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from 'react';
import { PageId } from './types';
import Header from './components/Header';
import Footer from './components/Footer';
import LeadAdminModal from './components/LeadAdminModal';
import Home from './pages/Home';
import About from './pages/About';
import ServicesPage from './pages/ServicesPage';
import Contact from './pages/Contact';

export default function App() {
  const [activePage, setActivePage] = useState<PageId>('home');
  const [leadReloadToggle, setLeadReloadToggle] = useState<number>(0);

  // Scroll to footer contact form
  const handleOpenSurvey = () => {
    const footerElement = document.getElementById('footer-lead-capture');
    if (footerElement) {
      footerElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
      // If footer not found in DOM immediately, navigate home and scroll
      setActivePage('home');
      setTimeout(() => {
        const foot = document.getElementById('footer-lead-capture');
        if (foot) foot.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 100);
    }
  };

  const handleLeadSubmitted = () => {
    // Increment count to trigger live preview refresh inside Sandbox drawer
    setLeadReloadToggle(prev => prev + 1);
  };

  const handleNavigate = (page: PageId) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Render proper page layout
  const renderPage = () => {
    switch (activePage) {
      case 'home':
        return <Home onNavigate={handleNavigate} onOpenSurvey={handleOpenSurvey} />;
      case 'about':
        return <About />;
      case 'services':
        return <ServicesPage onOpenSurvey={handleOpenSurvey} />;
      case 'contact':
        return <Contact />;
      default:
        return <Home onNavigate={handleNavigate} onOpenSurvey={handleOpenSurvey} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans transition-colors duration-300 selection:bg-cyan-500 selection:text-slate-950">
      
      {/* Sticky Header */}
      <Header
        activePage={activePage}
        setActivePage={handleNavigate}
        onOpenSurvey={handleOpenSurvey}
      />

      {/* Main Page Layout Wrapper */}
      <main className="flex-grow">
        {renderPage()}
      </main>

      {/* Leads CRM offline validation Sandbox */}
      <LeadAdminModal refreshTrigger={leadReloadToggle} />

      {/* Corporate footer with integrated Lead Survey form */}
      <Footer
        onNavigate={handleNavigate}
        onLeadSubmitted={handleLeadSubmitted}
      />

    </div>
  );
}
