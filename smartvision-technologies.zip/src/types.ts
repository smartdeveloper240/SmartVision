/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PageId = 'home' | 'about' | 'services' | 'contact';

export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  iconName: string;
  features: string[];
  benefits: string[];
  imageSrc?: string;
}

export interface ValueCard {
  title: string;
  description: string;
  iconName: string;
}

export interface IndustryCard {
  id: string;
  title: string;
  description: string;
  details: string[];
  iconName: string;
  tag: string;
}

export interface LeadSubmission {
  id: string;
  name: string;
  phone: string;
  email: string;
  serviceNeeded: string;
  message: string;
  timestamp: string;
  status: 'new' | 'contacted' | 'resolved';
}

export interface ContactInfo {
  phone: string;
  email: string;
  address: string;
  hours: {
    weekdays: string;
    saturday: string;
    sunday: string;
  };
}
