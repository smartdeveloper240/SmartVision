/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { LeadSubmission } from '../types';
import { DynamicIcon } from './Icons';
import { motion, AnimatePresence } from 'motion/react';

interface LeadAdminModalProps {
  refreshTrigger: number;
}

export default function LeadAdminModal({ refreshTrigger }: LeadAdminModalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [leads, setLeads] = useState<LeadSubmission[]>([]);
  const [filter, setFilter] = useState<'all' | 'new' | 'contacted' | 'resolved'>('all');

  // Load leads from localStorage
  const loadLeads = () => {
    try {
      const stored = localStorage.getItem('smartvision_leads');
      if (stored) {
        setLeads(JSON.parse(stored));
      } else {
        // Hydrate seed leads for the demo
        const seedLeads: LeadSubmission[] = [
          {
            id: 'seed-1',
            name: 'Robert Hastings (Enterprise)',
            phone: '+1 (555) 432-1550',
            email: 'hastings@apexmanufacturing.org',
            serviceNeeded: 'CCTV Surveillance Systems',
            message: 'Need 30 UHD IP cameras deployed across our Eastern distribution warehouse with thermal triggers and AMC pricing.',
            timestamp: '2026-06-16, 11:24:00 AM',
            status: 'new'
          },
          {
            id: 'seed-2',
            name: 'Clara Oswald',
            phone: '+1 (555) 901-3827',
            email: 'clara@oswaldconsulting.com',
            serviceNeeded: 'Networking & Fiber Infrastructure',
            message: 'Moving to a 3-story block. Need clean structured Cat6a LAN cabling, rack patching and Wi-Fi channels optimized.',
            timestamp: '2026-06-14, 2:45:00 PM',
            status: 'contacted'
          }
        ];
        localStorage.setItem('smartvision_leads', JSON.stringify(seedLeads));
        setLeads(seedLeads);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadLeads();
  }, [refreshTrigger, isOpen]);

  const updateLeadStatus = (id: string, newStatus: 'new' | 'contacted' | 'resolved') => {
    const updated = leads.map(l => {
      if (l.id === id) {
        return { ...l, status: newStatus };
      }
      return l;
    });
    setLeads(updated);
    localStorage.setItem('smartvision_leads', JSON.stringify(updated));
  };

  const deleteLead = (id: string) => {
    const updated = leads.filter(l => l.id !== id);
    setLeads(updated);
    localStorage.setItem('smartvision_leads', JSON.stringify(updated));
  };

  const clearAllLeads = () => {
    if (window.confirm('Clear all Lead submissions from sandbox?')) {
      localStorage.setItem('smartvision_leads', JSON.stringify([]));
      setLeads([]);
    }
  };

  const filteredLeads = leads.filter(l => {
    if (filter === 'all') return true;
    return l.status === filter;
  });

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'new':
        return 'bg-amber-950/70 text-amber-300 border border-amber-500/30';
      case 'contacted':
        return 'bg-blue-950/70 text-blue-300 border border-blue-500/30';
      case 'resolved':
        return 'bg-emerald-950/70 text-emerald-300 border border-emerald-500/30';
      default:
        return 'bg-slate-800 text-slate-300';
    }
  };

  return (
    <>
      {/* Floating Badges Toggle button */}
      <div className="fixed bottom-6 right-6 z-50">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="bg-slate-900 border border-slate-700/80 hover:border-cyan-400 text-white px-4 py-3 rounded-full flex items-center gap-2.5 shadow-2xl cursor-pointer hover:bg-slate-850 transition-all duration-300 transform active:scale-95 group"
        >
          <div className="relative">
            <DynamicIcon name="Database" className="w-5 h-5 text-cyan-400 group-hover:animate-pulse" />
            {leads.filter(l => l.status === 'new').length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-2.5 h-2.5 bg-rose-500 rounded-full border border-slate-900 animate-ping"></span>
            )}
          </div>
          <span className="text-sm font-semibold tracking-wide">
            Leads Sandbox
          </span>
          <span className="bg-cyan-950/60 text-cyan-400 border border-cyan-800/40 text-xs px-2 py-0.5 rounded-full font-mono">
            {leads.length}
          </span>
        </button>
      </div>

      {/* Admin Panel Drawer / Modal */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex justify-end">
            
            {/* Modal Backdrop Exit anchor */}
            <div className="absolute inset-0 cursor-pointer" onClick={() => setIsOpen(false)} />

            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="relative w-full max-w-2xl bg-slate-900 border-l border-slate-800 shadow-2xl h-full flex flex-col z-10"
            >
              
              {/* Header */}
              <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950">
                <div className="flex items-center gap-2.5">
                  <div className="bg-cyan-500/10 p-2 rounded-lg">
                    <DynamicIcon name="Database" className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <h2 className="text-white font-extrabold text-base tracking-tight">
                      SmartVision Lead Management
                    </h2>
                    <p className="text-[11px] text-slate-400 font-mono">
                      Offline CRM sandbox stored in local state
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                >
                  <DynamicIcon name="X" className="w-5 h-5" />
                </button>
              </div>

              {/* CRM Toolbar / Filters */}
              <div className="p-4 bg-slate-900/50 border-b border-slate-800 flex flex-wrap gap-2 items-center justify-between">
                <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800">
                  {(['all', 'new', 'contacted', 'resolved'] as const).map(f => (
                    <button
                      key={f}
                      onClick={() => setFilter(f)}
                      className={`px-3 py-1 text-xs rounded font-medium capitalize cursor-pointer transition-all ${
                        filter === f
                          ? 'bg-cyan-500 text-slate-950 font-bold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>

                <button
                  onClick={clearAllLeads}
                  className="px-3 py-1.5 text-xs text-rose-400 hover:text-rose-300 hover:bg-rose-950/20 rounded font-medium border border-rose-900/30 hover:border-rose-800 transition-colors cursor-pointer"
                >
                  Clear Sandbox
                </button>
              </div>

              {/* Lead items scroll list */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-950/45">
                {filteredLeads.length === 0 ? (
                  <div className="text-center py-16 space-y-3">
                    <div className="inline-flex bg-slate-900 p-4 rounded-full border border-slate-800 mb-2">
                      <DynamicIcon name="Inbox" className="w-8 h-8 text-slate-500" />
                    </div>
                    <p className="text-slate-400 font-medium">No Lead Submissions Found</p>
                    <p className="text-xs text-slate-500 max-w-xs mx-auto">
                      Fill out the "Request a Free Site Survey" form in the page footer to capture a new lead.
                    </p>
                  </div>
                ) : (
                  filteredLeads.map((lead) => (
                    <div
                      key={lead.id}
                      className="bg-slate-900 border border-slate-800/80 rounded-xl p-5 shadow-md relative group hover:border-slate-700 transition"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                        <div>
                          <h4 className="text-white font-bold text-sm tracking-wide">
                            {lead.name}
                          </h4>
                          <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                            Logged: {lead.timestamp}
                          </span>
                        </div>
                        <span className={`text-[10px] font-semibold font-mono tracking-wider px-2 py-0.5 rounded-full ${getStatusBadgeClass(lead.status)}`}>
                          {lead.status.toUpperCase()}
                        </span>
                      </div>

                      {/* Details of individual lead */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 py-3 text-xs">
                        <div>
                          <span className="text-slate-500 block">Phone</span>
                          <span className="font-mono text-slate-300 font-medium">{lead.phone}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block">Email Address</span>
                          <span className="text-slate-300 font-medium">{lead.email}</span>
                        </div>
                        <div className="sm:col-span-2 bg-slate-950/60 p-2 rounded border border-slate-800/40 mt-1">
                          <span className="text-slate-500 block text-[10px] uppercase font-mono tracking-wider">
                            Service solution needed:
                          </span>
                          <span className="text-cyan-400 font-semibold">{lead.serviceNeeded}</span>
                        </div>
                      </div>

                      {lead.message && (
                        <div className="bg-slate-950 p-3 rounded-lg border border-slate-850 text-xs text-slate-300 leading-relaxed mb-4">
                          <span className="text-slate-500 font-mono text-[10px] block mb-1">NOTES / MESSAGE:</span>
                          {lead.message}
                        </div>
                      )}

                      {/* Admin interaction buttons */}
                      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800 bg-slate-900">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[11px] text-slate-500 hidden sm:inline-block">Status:</span>
                          <select
                            value={lead.status}
                            onChange={(e) => updateLeadStatus(lead.id, e.target.value as any)}
                            className="bg-slate-950 text-slate-300 text-xs rounded border border-slate-800 px-2.5 py-1 outline-none cursor-pointer focus:border-cyan-400"
                          >
                            <option value="new">New</option>
                            <option value="contacted">Contacted</option>
                            <option value="resolved">Resolved</option>
                          </select>
                        </div>

                        <button
                          onClick={() => deleteLead(lead.id)}
                          className="text-xs text-slate-400 hover:text-rose-400 hover:bg-rose-950/10 px-2.5 py-1.5 rounded border border-slate-800 hover:border-rose-900/40 transition-colors cursor-pointer"
                        >
                          Delete Record
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Developer note footer block */}
              <div className="p-4 bg-slate-950 border-t border-slate-800 text-slate-400 text-xs leading-relaxed flex items-start gap-2">
                <DynamicIcon name="CheckCircle2" className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Prototype CRM validation:</strong> Stored under localStorage. Real-world applications would serialize lead inputs down to a cloud-database like Google Firestore using the Firebase Integration skill.
                </span>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
