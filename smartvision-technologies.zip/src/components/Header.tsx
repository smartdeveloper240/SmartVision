/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { PageId } from '../types';
import { COMP_NAME } from '../data';
import { DynamicIcon } from './Icons';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  activePage: PageId;
  setActivePage: (page: PageId) => void;
  onOpenSurvey: () => void;
}

export default function Header({ activePage, setActivePage, onOpenSurvey }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { id: PageId; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'services', label: 'Our Services' },
    { id: 'contact', label: 'Contact & Support' },
  ];

  const handleNavClick = (pageId: PageId) => {
    setActivePage(pageId);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-slate-900/95 backdrop-blur-md shadow-lg border-b border-slate-800/80 py-3'
          : 'bg-slate-900 py-5 border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo & Brand */}
          <div
            id="header-logo"
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => handleNavClick('home')}
          >
            <div className="bg-cyan-500 text-slate-900 p-2 rounded-lg flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <DynamicIcon name="Shield" className="w-6 h-6 text-slate-950 font-bold" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-sans font-extrabold tracking-tight text-white text-lg sm:text-xl">
                  SmartVision<span className="text-cyan-400">Tech</span>
                </span>
                <span className="text-cyan-400 font-medium text-[10px] bg-cyan-950 px-2 py-0.5 rounded border border-cyan-400/20 hidden sm:inline-block">
                  ENTERPRISE
                </span>
              </div>
              <p className="text-[10px] font-mono tracking-widest text-slate-400 uppercase leading-none mt-0.5">
                Technologies
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav id="desktop-nav" className="hidden md:flex items-center gap-1 lg:gap-2">
            {navItems.map((item) => {
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`relative px-4 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer ${
                    isActive ? 'text-cyan-400 font-semibold' : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <motion.div
                      layoutId="activeNavIndicator"
                      className="absolute bottom-0 left-4 right-4 h-0.5 bg-cyan-400 rounded-full"
                      transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* CTA Button */}
          <div id="header-cta" className="hidden md:flex items-center gap-4">
            <button
              onClick={onOpenSurvey}
              className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 px-5 py-2.5 rounded-lg text-sm font-semibold tracking-wide transition-all duration-250 cursor-pointer shadow-lg shadow-cyan-500/15 hover:shadow-cyan-500/30 flex items-center gap-2 transform active:scale-95"
            >
              <span>Free Site Survey</span>
              <DynamicIcon name="ArrowRight" className="w-4 h-4 text-slate-950" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div id="mobile-menu-btn" className="flex md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              aria-label="Toggle Menu"
            >
              <DynamicIcon name={isMobileMenuOpen ? 'X' : 'Menu'} className="w-6 h-6" />
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            id="mobile-drawer"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="md:hidden bg-slate-900 border-b border-slate-800 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-2 border-t border-slate-800/60">
              {navItems.map((item) => {
                const isActive = activePage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`block w-full text-left px-4 py-3 rounded-lg text-base font-medium transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-cyan-950/60 text-cyan-400 font-semibold border-l-4 border-cyan-400 pl-3'
                        : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
              <div className="pt-4 px-4">
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onOpenSurvey();
                  }}
                  className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 py-3 rounded-lg text-center text-sm font-semibold tracking-wide transition-all duration-200 cursor-pointer shadow-lg flex items-center justify-center gap-2"
                >
                  <span>Request Free Site Survey</span>
                  <DynamicIcon name="ArrowRight" className="w-4 h-4 text-slate-950" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
