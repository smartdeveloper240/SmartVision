/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Camera,
  Network,
  Lock,
  CheckCircle2,
  Shield,
  ShieldAlert,
  Users,
  Sliders,
  DollarSign,
  Home,
  Building2,
  GraduationCap,
  Cpu,
  Phone,
  Mail,
  MapPin,
  Clock,
  ArrowRight,
  Menu,
  X,
  Star,
  Check,
  ChevronRight,
  ChevronDown,
  Database,
  Inbox,
  Award,
  BookOpen,
  Settings,
  Bell,
  HardDrive
} from 'lucide-react';

export const IconMap = {
  Camera,
  Network,
  Lock,
  CheckCircle2,
  Shield,
  ShieldAlert,
  Users,
  Sliders,
  DollarSign,
  Home,
  Building2,
  GraduationCap,
  Cpu,
  Phone,
  Mail,
  MapPin,
  Clock,
  ArrowRight,
  Menu,
  X,
  Star,
  Check,
  ChevronRight,
  ChevronDown,
  Database,
  Inbox,
  Award,
  BookOpen,
  Settings,
  Bell,
  HardDrive
};

export type IconNames = keyof typeof IconMap;

interface DynIconProps {
  name: string;
  className?: string;
  size?: number;
  key?: any;
}

export function DynamicIcon({ name, className = '', size = 20 }: DynIconProps) {
  const IconComponent = (IconMap as any)[name] || Shield;
  return <IconComponent className={className} size={size} />;
}
