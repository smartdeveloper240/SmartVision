/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PageId, LeadSubmission } from '../types';
import { COMP_NAME, CONTACT_METADATA } from '../data';
import { DynamicIcon } from './Icons';
import { motion, AnimatePresence } from 'motion/react';

interface FooterProps {
  onNavigate: (page: PageId) => void;
  onLeadSubmitted?: () => void;
}

export default function Footer({ onNavigate, onLeadSubmitted }: FooterProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    serviceNeeded: 'CCTV Surveillance Systems',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [validationError, setValidationError] = useState('');

  const servicesDropdown = [
    'CCTV Surveillance Systems',
    'Networking & Fiber Infrastructure',
    'Access Control & Automation',
    'Annual Maintenance Contract (AMC)',
    'Other Security/Networking Inquiry'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (validationError) setValidationError('');
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple verification
    if (!formData.name.trim() || !formData.email.trim() || !formData.phone.trim()) {
      setValidationError('Please complete the Name, Phone, & Email inputs.');
      return;
    }

    setIsSubmitting(true);

    // Simulate database write
    setTimeout(() => {
      try {
        const stored = localStorage.getItem('smartvision_leads');
        const leads: LeadSubmission[] = stored ? JSON.parse(stored) : [];
        
        const newLead: LeadSubmission = {
          id: 'lead_' + Math.random().toString(36).substr(2, 9),
          name: formData.name,
          phone: formData.phone,
          email: formData.email,
          serviceNeeded: formData.serviceNeeded,
          message: formData.message,
          timestamp: new Date().toLocaleString(),
          status: 'new'
        };

        leads.unshift(newLead);
        localStorage.setItem('smartvision_leads', JSON.stringify(leads));
        
        setIsSubmitting(false);
        setSubmitSuccess(true);
        setFormData({
          name: '',
          phone: '',
          email: '',
          serviceNeeded: 'CCTV Surveillance Systems',
          message: ''
        });

        // Trigger parent state if callback defined
        if (onLeadSubmitted) {
          onLeadSubmitted();
        }

        // Reset success state after 5 seconds to allow other entries
        setTimeout(() => setSubmitSuccess(false), 5000);
      } catch (err) {
        setIsSubmitting(false);
        setValidationError('Failed to save submission. Please try again.');
      }
    }, 900);
  };

  return (
    <footer id="main-footer" className="bg-slate-950 text-slate-400 pt-16 pb-8 border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-16 border-b border-slate-800">
          
          {/* Company Brief & Metadata */}
          <div className="lg:col-span-5 space-y-6">
            <div className="flex items-center gap-3">
              <div className="bg-cyan-500 text-slate-950 p-2 rounded-lg flex items-center justify-center">
                <DynamicIcon name="Shield" className="w-6 h-6 text-slate-950" />
              </div>
              <div>
                <span className="font-sans font-extrabold tracking-tight text-white text-xl">
                  SmartVision<span className="text-cyan-400">Tech</span>
                </span>
                <p className="text-[10px] font-mono tracking-widest text-slate-400 uppercase leading-none mt-0.5">
                  Technologies
                </p>
              </div>
            </div>
            
            <p className="text-slate-300 text-sm leading-relaxed max-w-md">
              Professional smart security layouts, CCTV surveillance architecture, and high-speed networking solutions. We deliver next-generation design and continuous technical monitoring for residences, businesses, and critical industries.
            </p>

            <div className="space-y-4 pt-2">
              <h4 className="text-white font-semibold text-xs uppercase tracking-wider font-mono">
                Corporate Headquarters
              </h4>
              <div className="flex items-start gap-3">
                <DynamicIcon name="MapPin" className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <span className="text-slate-300 text-sm leading-relaxed">
                  {CONTACT_METADATA.address}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <DynamicIcon name="Phone" className="w-5 h-5 text-cyan-400 shrink-0" />
                <a href={`tel:${CONTACT_METADATA.phone}`} className="text-slate-300 hover:text-cyan-400 text-sm transition-colors font-mono">
                  {CONTACT_METADATA.phone}
                </a>
              </div>
              <div className="flex items-center gap-3">
                <DynamicIcon name="Mail" className="w-5 h-5 text-cyan-400 shrink-0" />
                <a href={`mailto:${CONTACT_METADATA.email}`} className="text-slate-300 hover:text-cyan-400 text-sm transition-colors">
                  {CONTACT_METADATA.email}
                </a>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-900">
              <h4 className="text-slate-400 font-semibold text-xs uppercase tracking-wider font-mono flex items-center gap-2">
                <DynamicIcon name="Clock" className="w-4 h-4 text-cyan-400" />
                Operational Hours
              </h4>
              <p className="text-xs text-slate-300">
                <span className="font-semibold text-slate-400">Weekdays:</span> {CONTACT_METADATA.hours.weekdays}
              </p>
              <p className="text-xs text-slate-300">
                <span className="font-semibold text-slate-400">Saturdays:</span> {CONTACT_METADATA.hours.saturday}
              </p>
              <p className="text-xs text-rose-400 italic">
                <span className="font-semibold text-slate-400 not-italic">Sundays:</span> {CONTACT_METADATA.hours.sunday}
              </p>
            </div>
          </div>

          {/* Quick Links Map */}
          <div className="lg:col-span-2 hidden lg:block space-y-6">
            <div>
              <h4 className="text-white font-bold text-sm tracking-wide">
                Solutions
              </h4>
              <div className="h-1 w-8 bg-cyan-500 rounded mt-1.5 mb-4"></div>
            </div>
            <ul className="space-y-3 text-sm">
              <li>
                <button onClick={() => { onNavigate('services'); window.scrollTo(0,0); }} className="hover:text-cyan-400 hover:underline text-left cursor-pointer transition-colors block">
                  CCTV Surveillance
                </button>
              </li>
              <li>
                <button onClick={() => { onNavigate('services'); window.scrollTo(0,0); }} className="hover:text-cyan-400 hover:underline text-left cursor-pointer transition-colors block">
                  Structured LAN
                </button>
              </li>
              <li>
                <button onClick={() => { onNavigate('services'); window.scrollTo(0,0); }} className="hover:text-cyan-400 hover:underline text-left cursor-pointer transition-colors block">
                  Fiber Backbones
                </button>
              </li>
              <li>
                <button onClick={() => { onNavigate('services'); window.scrollTo(0,0); }} className="hover:text-cyan-400 hover:underline text-left cursor-pointer transition-colors block">
                  Biometric Access
                </button>
              </li>
              <li>
                <button onClick={() => { onNavigate('services'); window.scrollTo(0,0); }} className="hover:text-cyan-400 hover:underline text-left cursor-pointer transition-colors block">
                  Video Intercoms
                </button>
              </li>
            </ul>

            <div className="pt-4">
              <h4 className="text-white font-bold text-sm tracking-wide">
                Company
              </h4>
              <div className="h-1 w-8 bg-cyan-500 rounded mt-1.5 mb-4"></div>
              <ul className="space-y-3 text-sm">
                <li>
                  <button onClick={() => { onNavigate('about'); window.scrollTo(0,0); }} className="hover:text-cyan-400 hover:underline text-left cursor-pointer transition-colors block">
                    Our Mission
                  </button>
                </li>
                <li>
                  <button onClick={() => { onNavigate('about'); window.scrollTo(0,0); }} className="hover:text-cyan-400 hover:underline text-left cursor-pointer transition-colors block">
                    Why Choose Us
                  </button>
                </li>
                <li>
                  <button onClick={() => { onNavigate('contact'); window.scrollTo(0,0); }} className="hover:text-cyan-400 hover:underline text-left cursor-pointer transition-colors block">
                    Contact Us
                  </button>
                </li>
              </ul>
            </div>
          </div>

          {/* LEAD CAPTURE FORM CONTROLS */}
          <div id="footer-lead-capture" className="lg:col-span-5 bg-slate-900 border border-slate-800/80 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/5 rounded-full blur-3xl"></div>
            <div>
              <span className="text-cyan-400 font-mono text-xs uppercase tracking-widest font-semibold flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
                Secure Dispatch
              </span>
              <h3 className="text-white font-bold text-lg sm:text-xl mt-1">
                Request a Free Site Survey
              </h3>
              <p className="text-slate-400 text-xs mt-1">
                Get an onsite layout audit and flat price quotation from our tech team.
              </p>
            </div>

            <AnimatePresence mode="wait">
              {submitSuccess ? (
                <motion.div
                  key="success-prompt"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="bg-emerald-950/50 border border-emerald-500/30 text-emerald-300 p-6 rounded-xl space-y-4"
                >
                  <div className="flex items-center gap-3">
                    <div className="bg-emerald-500 text-slate-950 p-1.5 rounded-full flex items-center justify-center">
                      <DynamicIcon name="Check" className="w-5 h-5 text-slate-950" />
                    </div>
                    <span className="font-bold text-white text-base">Request Submitted!</span>
                  </div>
                  <p className="text-sm text-emerald-400 leading-relaxed">
                    Thank you. We have recorded your parameters. A certified field technician will contact you shortly to schedule your physical survey.
                  </p>
                  <div className="text-xs text-cyan-400 font-mono bg-cyan-950/40 p-2.5 rounded border border-cyan-800/20">
                    💡 Tip: Click the floating 'Lead Sandbox' helper badge at bottom-right of the window to verify layout submissions.
                  </div>
                </motion.div>
              ) : (
                <motion.form
                  key="form-fields"
                  onSubmit={handleFormSubmit}
                  className="space-y-4"
                >
                  {validationError && (
                    <div className="bg-rose-950/40 border border-rose-500/25 p-3 rounded-lg text-rose-300 text-xs">
                      ⚠️ {validationError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="name-input" className="block text-slate-300 text-xs font-medium mb-1.5">
                        Your Full Name
                      </label>
                      <input
                        type="text"
                        id="name-input"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="John Doe"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-lg px-3 py-2 text-sm text-white outline-none transition-colors"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="phone-input" className="block text-slate-300 text-xs font-medium mb-1.5">
                        Contact Phone
                      </label>
                      <input
                        type="tel"
                        id="phone-input"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="+1 (555) 000-0000"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-lg px-3 py-2 text-sm text-white outline-none transition-colors"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="email-input" className="block text-slate-300 text-xs font-medium mb-1.5">
                      Business or Personal Email
                    </label>
                    <input
                      type="email"
                      id="email-input"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="johndoe@company.com"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-400 rounded-lg px-3 py-2 text-sm text-white outline-none transition-colors"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="service-dropdown" className="block text-slate-300 text-xs font-medium mb-1.5">
                      Service Solution Needed
                    </label>
                    <select
                      id="service-dropdown"
                      name="serviceNeeded"
                      value={formData.serviceNeeded}
                      onChange={handleInputChange}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-400 rounded-lg px-3 py-2 text-sm text-white outline-none transition-colors cursor-pointer"
                    >
                      {servicesDropdown.map((option) => (
                        <option key={option} value={option} className="bg-slate-950 text-white">
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label htmlFor="message-input" className="block text-slate-300 text-xs font-medium mb-1.5">
                      Project Details / Message (Optional)
                    </label>
                    <textarea
                      id="message-input"
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="List any details regarding property dimensions or required camera quantities..."
                      rows={2}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-400 rounded-lg px-3 py-2 text-sm text-white outline-none transition-colors resize-none"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-3 px-4 rounded-lg tracking-wider text-sm transition-all duration-200 cursor-pointer shadow-lg shadow-cyan-500/10 flex items-center justify-center gap-2 transform active:scale-98"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span>
                        <span>Logging Parameters...</span>
                      </>
                    ) : (
                      <>
                        <span>Submit Survey Proposal</span>
                        <DynamicIcon name="ArrowRight" className="w-4 h-4 text-slate-950" />
                      </>
                    )}
                  </button>
                </motion.form>
              )}
            </AnimatePresence>
          </div>

        </div>

        {/* Lower copyright bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} {COMP_NAME}. All Rights Reserved. Smart Security. Smart Connectivity.</p>
          <div className="flex gap-6">
            <span className="hover:text-slate-400 cursor-pointer">Security Certifications: ISMS-27001</span>
            <span className="hover:text-slate-400 cursor-pointer">Privacy Protocol</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
