/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ServiceItem, ValueCard, IndustryCard, ContactInfo } from './types';

export const COMP_NAME = 'SmartVision Technologies';
export const TAGLINE = 'Smart Security. Smart Connectivity.';

export const CONTACT_METADATA: ContactInfo = {
  phone: '+1 (800) 555-0199',
  email: 'solutions@smartvisiontech.com',
  address: '100 Tech Venture Parkway, Suite 450, Innovation District',
  hours: {
    weekdays: '8:00 AM - 6:00 PM (EST)',
    saturday: '9:00 AM - 3:00 PM (EST)',
    sunday: 'Emergency AMC On-Call Support Only'
  }
};

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'cctv',
    title: 'CCTV Surveillance Systems',
    shortDesc: 'HD/IP Cameras, DVR/NVR Setup, Remote Monitoring, and comprehensive Annual Maintenance Contracts (AMC).',
    fullDesc: 'Our high-definition CCTV systems offer cutting-edge optical surveillance tailored for high-risk corporate, industrial, and residential applications. With intelligent video analytics, perimeter guard controls, and smart motion notifications, we ensure that your property remains actively protected and monitored from anywhere in the world.',
    iconName: 'Camera',
    features: [
      'High-Definition Ultra HD 4K IP Surveillance Cameras',
      'Intelligent NVR/DVR multi-channel network configuration',
      'Secure remote cloud streaming and legacy mobile application support',
      'Annual Maintenance Contracts (AMC) with guaranteed same-day dispatch'
    ],
    benefits: [
      'Active deterrent against unauthorized access & perimeter intrusion',
      'Crystal-clear recording with star-light full-color night vision capabilities',
      'Encrypted playback streams safeguard private video logs',
      'AI-powered thermal mapping and automatic perimeter counting'
    ],
    imageSrc: '/src/assets/images/smartvision_cctv_1781679350875.jpg'
  },
  {
    id: 'networking',
    title: 'Networking & Fiber Solutions',
    shortDesc: 'Custom office network setup, professional structured cabling, Wi-Fi channel optimization, and private fiber networks.',
    fullDesc: 'Connectivity is the lifeblood of modern enterprise. We engineer stable, high-throughput network backbones designed to support intensive digital operations without packet loss or dropouts. From premium structured cabling layouts to robust multi-ap Wi-Fi mesh systems, we create communication pipelines built to last.',
    iconName: 'Network',
    features: [
      'Multi-floor high-performance structured cabling layouts (Cat6a/Cat7)',
      'Enterprise-grade managed switching & router setups',
      'Professional point-to-point wireless bridge and Wi-Fi 6 AP setups',
      'Dedicated private single-mode and multi-mode fiber optic terminations'
    ],
    benefits: [
      'Unfettered data speed with ultra-low latency guarantees',
      'Elimination of network blindspots and dynamic congestion zones',
      'Flexible, modular scaling for future devices and hardware refreshes',
      'Enhanced local security featuring specialized virtual local area networks (VLANs)'
    ]
  },
  {
    id: 'access-control',
    title: 'Smart Security & Access Control',
    shortDesc: 'Advanced access control panel, biometric fingerprint scanners, facial gateways, and secure video door phones.',
    fullDesc: 'Regulate your facilities with highly integrated access solutions. Eliminate outdated physical keys and take precise control over physical personnel flow. Our access control system provides continuous digital verification logs, automated door-lock integration, and direct synergy with video endpoints.',
    iconName: 'Lock',
    features: [
      'Advanced biometric readers (fingerprint, card-less RFID, facial geometry)',
      'High-definition door stations and interactive indoor video panels',
      'Magnetic lock integrations with fire-alarm failsafe protocols',
      'Central desktop management software with robust remote gate controls'
    ],
    benefits: [
      'Guaranteed electronic record of all personnel movements',
      'Instant access revocation for terminated credentials or lost cards',
      'Failsafe emergency routing ensures compliance with municipal building codes',
      'Optimized visitor screening with secure two-way audiovisual intercoms'
    ]
  }
];

export const WHY_CHOOSE_US: ValueCard[] = [
  {
    title: 'Professional Installation',
    description: 'Every deployment is executed by certified field technicians, ensuring pristine cable management, optimal viewing angles, and secure anchor mounting.',
    iconName: 'CheckCircle2'
  },
  {
    title: 'Premium Brand Selection',
    description: 'We source only tier-one commercial equipment and industry-leading enterprise hardware with robust manufacturer warranties.',
    iconName: 'ShieldAlert'
  },
  {
    title: 'Expert AMC Support',
    description: 'Our customer care operations offer active remote diagnostics, preventive onsite checks, and rapid response dispatches for AMC partners.',
    iconName: 'Users'
  },
  {
    title: 'Customized Space Layouts',
    description: 'No template-based security. We perform rigorous spatial site surveys to engineer customized camera layouts and optimal cabling maps.',
    iconName: 'Sliders'
  },
  {
    title: 'Transparent Flat Pricing',
    description: 'Detailed competitive items, clear parts and labor breakdowns, absolute zero hidden charges, and clear service definitions.',
    iconName: 'DollarSign'
  }
];

export const INDUSTRIES_DATA: IndustryCard[] = [
  {
    id: 'residential',
    title: 'Residential Complexes',
    description: 'Securing smart gated villas, high-rise apartment clusters, and integrated community units with remote alert networks.',
    details: ['Video Intercom Gateways', 'Community CCTV Grids', 'Smart Home App Integrations'],
    iconName: 'Home',
    tag: 'Safe Homes'
  },
  {
    id: 'commercial',
    title: 'Corporate Offices',
    description: 'Optimizing corporate workspaces with synchronized biometrics, segmented high-speed Wi-Fi networks, and server-room access logs.',
    details: ['Biometric Access Control', 'Multi-Floor Wi-Fi Networks', 'Server Room Vault Locks'],
    iconName: 'Building2',
    tag: 'Connected Workspaces'
  },
  {
    id: 'institutional',
    title: 'Educational Institutions',
    description: 'Designing robust campus surveillance arrays, safe student environments, and modular auditorium networking.',
    details: ['Perimeter Protection', 'Smart PA Broadcast Channels', 'Secure Campus Wi-Fi Backbones'],
    iconName: 'GraduationCap',
    tag: 'Shielded Campus'
  },
  {
    id: 'industrial',
    title: 'Industrial & Warehouses',
    description: 'Deploying heavy-duty dustproof cameras, thermal alarm sensors, and long-range secure fiber links across multi-site layouts.',
    details: ['IP67 Heavy-Duty Cameras', 'Thermal Fire Alarms', 'Structured Fiber Backbones'],
    iconName: 'Cpu',
    tag: 'Hardened Security'
  }
];

export const OUR_REVIEWS = [
  {
    quote: "SmartVision handled our multi-floor corporate office transition flawlessly. The network infrastructure is blazing fast and the secure biometric entries operate absolute smoothly.",
    author: "Amanda Sterling",
    role: "Lead Systems Architect, Apex Global Corp",
    rating: 5
  },
  {
    quote: "Our manufacturing center required specialized dust-rated cameras and structured fiber layouts. Their engineers completed the layout ahead of schedule and with perfect detail.",
    author: "Marcus Vance",
    role: "Operations Director, Summit Logistics Ltd",
    rating: 5
  },
  {
    quote: "The peace of mind this service survey and CCTV remote monitoring structure brings is incredible. High quality imagery and super responsive AMC help desk.",
    author: "Elena Rostov",
    role: "Property Manager, Grand Plaza Residences",
    rating: 5
  }
];

export const FREQUENT_QUESTIONS = [
  {
    question: "Do you offer complimentary site surveys to evaluate our security needs?",
    answer: "Absolutely! We provide comprehensive, no-obligation physical site surveys for homes, offices, schools, and heavy industries. Our engineers will audit your layout, identify blindspots, and provide a tailored spatial design proposal."
  },
  {
    question: "What is an AMC, and how does it safeguard our technical investments?",
    answer: "An AMC (Annual Maintenance Contract) is our premium security assurance agreement. It includes quarterly proactive technician checkups, emergency lens adjustments, firmware patches, continuous cable audits, and priority same-day dispatch in the rare event of hardware failures."
  },
  {
    question: "How long does a typical office IT network and CCTV layout installation take?",
    answer: "A standard small-to-medium office setup is usually deployed and verified within 2 to 4 business days. Large industrial warehouses or educational campuses with heavy structured cabling and fiber loops may require 1 to 2 weeks of carefully planned staging."
  },
  {
    question: "Can we monitor our surveillance cameras and entry gates via a phone app?",
    answer: "Yes, every modern IP camera system and door access intercom we install supports secure, hardware-encrypted remote streaming on iOS, Android, macOS, and Windows. Access can be easily segmented for different staff permissions."
  }
];
